#include<iostream>
#include<vector>
using namespace std;


pair<int,int> find_maxmin(vector<int> arr, int low, int high){

//base case

if(low==high){ //single element

return {arr[low],arr[low]};


}


//when two elements are left

if(low==high-1){

    return { max(arr[low],arr[high]) ,   min(arr[low],arr[high]) } ;

}


//divide

int mid = (low+high)/2;

pair<int,int> l_maxmin = find_maxmin(arr,low,mid); //{10,1}

pair<int,int> r_maxmin = find_maxmin(arr,mid+1,high); //{15,-1}

//merge/conquer

pair<int,int> res; //{max,min}

res.first = max(l_maxmin.first,r_maxmin.first); //max(10,15)

res.second = min(l_maxmin.second,r_maxmin.second); //min(1,-1)

return res; //{15,-1}







}




int main(){


/*pair<int,int> p;
p.first =10;
p.second = 15;
cout<<p.first<<endl;*/

vector<int> vec = {10,-1,5,15,-10};

pair<int,int> result = find_maxmin(vec,0,vec.size()-1);
cout<<"Max: "<<result.first<<endl;
cout<<"Min: "<<result.second<<endl;


}
